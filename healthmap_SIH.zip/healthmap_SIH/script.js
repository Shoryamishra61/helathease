// Initialize the map
const map = L.map('map').setView([13.0827, 80.2707], 13);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
}).addTo(map);

// Initialize a marker cluster group
const markers = L.markerClusterGroup().addTo(map);

// Simulated hospital data
const hospitals = [
    { name: 'Apollo Hospital', lat: 13.0827, lng: 80.2707, size: 'large', address: '123 Main Street, Chennai', contact: '+91 44 1234 5678', waitingTime: '30 mins', photo: 'https://via.placeholder.com/150' },
    { name: 'Fortis Hospital', lat: 13.0820, lng: 80.2710, size: 'medium', address: '456 Second Avenue, Chennai', contact: '+91 44 8765 4321', waitingTime: '20 mins', photo: 'https://via.placeholder.com/150' },
    { name: 'Care Hospital', lat: 13.0830, lng: 80.2720, size: 'small', address: '789 Third Boulevard, Chennai', contact: '+91 44 1122 3344', waitingTime: '15 mins', photo: 'https://via.placeholder.com/150' },
];

// Function to create hospital markers and add them to the cluster group
function createHospitalMarker(hospital) {
    const customIcon = L.icon({
        iconUrl: hospital.photo,
        iconSize: [40, 40],
        iconAnchor: [20, 40],
        popupAnchor: [0, -40],
    });

    const marker = L.marker([hospital.lat, hospital.lng], { icon: customIcon });
    marker.bindPopup(`
        <div class="popup-content">
            <h3>${hospital.name}</h3>
            <img src="${hospital.photo}" alt="${hospital.name}">
            <p><strong>Waiting Time:</strong> ${hospital.waitingTime}</p>
            <p><strong>Size:</strong> ${hospital.size}</p>
            <p><strong>Address:</strong> ${hospital.address}</p>
            <p><strong>Contact:</strong> ${hospital.contact}</p>
        </div>
    `);
    markers.addLayer(marker);
}

// Add all hospitals to the map
hospitals.forEach(createHospitalMarker);

// Function to show loading spinner
function showLoadingSpinner(show) {
    const spinner = document.getElementById('loading-spinner');
    if (show) {
        spinner.classList.remove('hidden');
    } else {
        spinner.classList.add('hidden');
    }
}

// Function to search for a location
document.getElementById('search-button').addEventListener('click', () => {
    const location = document.getElementById('search-input').value;
    if (location) {
        showLoadingSpinner(true);
        axios.get(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}`)
            .then(response => {
                showLoadingSpinner(false);
                if (response.data.length > 0) {
                    const lat = parseFloat(response.data[0].lat);
                    const lng = parseFloat(response.data[0].lon);
                    map.setView([lat, lng], 15);
                    addHospitalsToMap(lat, lng, 2000);  // Show hospitals within 2 km
                } else {
                    alert("Location not found.");
                }
            })
            .catch((error) => {
                showLoadingSpinner(false);
                alert("Error fetching location data: " + error.message);
            });
    } else {
        alert("Please enter a location.");
    }
});

// Function to add nearby hospitals to the map based on a given location and radius
function addHospitalsToMap(lat, lng, radius) {
    markers.clearLayers(); // Clear existing markers

    hospitals.forEach(hospital => {
        const distance = map.distance([lat, lng], [hospital.lat, hospital.lng]);
        if (distance <= radius) {
            createHospitalMarker(hospital);
        }
    });
}

// Use current location to find hospitals nearby
document.getElementById('current-location-button').addEventListener('click', () => {
    if (navigator.geolocation) {
        showLoadingSpinner(true);
        navigator.geolocation.getCurrentPosition((position) => {
            showLoadingSpinner(false);
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            map.setView([lat, lng], 15);
            addHospitalsToMap(lat, lng, 2000); // Show hospitals within 2 km
        }, () => {
            showLoadingSpinner(false);
            alert("Unable to retrieve your location.");
        });
    } else {
        alert("Geolocation is not supported by your browser.");
    }
});
